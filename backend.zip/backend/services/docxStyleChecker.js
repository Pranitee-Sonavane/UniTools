const docx4js = require("docx4js");

const docxStyleChecker = async (filePath) => {
  try {
    const doc = await docx4js.load(filePath);
    let fontOk = true;
    let fontSizeOk = true;
    let justifiedOk = true;

    const paragraphs = doc.getElementsByTagName("w:p");
    paragraphs.forEach(p => {
      // Alignment check
      const align = p.getElementsByTagName("w:jc")[0];
      if (!align || align.getAttribute("w:val") !== "both") justifiedOk = false;

      const runs = p.getElementsByTagName("w:r");
      runs.forEach(r => {
        const rPr = r.getElementsByTagName("w:rPr")[0];
        if (rPr) {
          const font = rPr.getElementsByTagName("w:ascii")[0];
          if (!font || font.getAttribute("w:val") !== "Times New Roman") fontOk = false;

          const size = rPr.getElementsByTagName("w:sz")[0];
          if (!size || ![24, 28, 32].includes(parseInt(size.getAttribute("w:val")))) fontSizeOk = false;
        }
      });
    });

    return { fontOk, fontSizeOk, justifiedOk };
  } catch (err) {
    console.error("DOCX style check error:", err);
    throw err;
  }
};

module.exports = docxStyleChecker;

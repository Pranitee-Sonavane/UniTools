const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const pdfChecker = require("../services/pdfChecker");
const docxChecker = require("../services/docxChecker");
const ruleEngine = require("../services/ruleEngine");

// Multer config
const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function(req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

// POST /api/submitsafe/check
router.post("/check", upload.single("file"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No file uploaded" });
console.log("Uploaded file info:", req.file);

  const filePath = req.file.path;
  const ext = path.extname(req.file.originalname).toLowerCase();
  let text = "";

  try {
    console.log("File extension:", ext);
    console.log("File path:", filePath);

    if (ext === ".pdf") {
      text = await pdfChecker(filePath);
    } else if (ext === ".docx") {
      text = await docxChecker(filePath);
    } else {
      return res.status(400).json({ error: "Unsupported file type" });
    }

    const checklistResults = ruleEngine(text, req.file);
    return res.json(checklistResults);

  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "File processing error" });
  }
});


module.exports = router;

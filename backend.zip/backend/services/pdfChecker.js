const fs = require("fs");
const pdfParse = require("pdf-parse");

const pdfChecker = async (filePath) => {
  try {
    const dataBuffer = fs.readFileSync(filePath);
    const pdfData = await pdfParse(dataBuffer);

    // pdfData.text contains all text from PDF
    return pdfData.text; 
  } catch (err) {
    console.error("PDF parsing error:", err);
    throw err;
  }
};

module.exports = pdfChecker;

const docxStyleChecker = require("./docxStyleChecker");

const ruleEngine = async (text, filePath) => {
  // Get font/size/justification results
  const styleResults = await docxStyleChecker(filePath);

  // Text-based checks
  const lowerText = text.toLowerCase();
  const hasIntroduction = lowerText.includes("introduction");
  const hasConclusion = lowerText.includes("conclusion");
  const pageOrder = lowerText.indexOf("introduction") < lowerText.indexOf("conclusion");

  // Margins / line spacing
  const lines = text.split(/\r\n|\r|\n/);
  const marginsOk = lines.length / 30 < 45; // approx normal
  const lineSpacingOk = true; // placeholder
  const pageNumbers = text.match(/\b\d+\b/g) ? true : false;

  // Plagiarism placeholder
  const plagiarism = true;

  // Merge everything into one result
  return {
    ...styleResults,
    pageNumbers,
    margins: marginsOk,
    lineSpacing: lineSpacingOk,
    hasIntroduction,
    hasConclusion,
    pageOrder,
    plagiarism
  };
};

module.exports = ruleEngine;

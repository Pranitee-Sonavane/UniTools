const mammoth = require("mammoth");

const docxChecker = async (filePath) => {
  try {
    const result = await mammoth.extractRawText({ path: filePath });
    return result.value; // extracted plain text
  } catch (err) {
    console.error("DOCX parsing error:", err);
    throw err;
  }
};

module.exports = docxChecker;
